#!/bin/bash
ansible-playbook /home/ec2-user/simple.yml -i localhost
