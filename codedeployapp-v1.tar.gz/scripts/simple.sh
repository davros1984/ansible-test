#!/bin/bash
yum -y install httpd
systemctl restart httpd
